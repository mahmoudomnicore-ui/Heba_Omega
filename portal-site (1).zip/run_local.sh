#!/usr/bin/env bash
# Starts the website AND your local image model. Then open http://localhost:8000
# Use another model by adding it after the command, e.g.:
#   ./run_local.sh --model black-forest-labs/FLUX.1-schnell
cd "$(dirname "$0")"
[ -f .venv/bin/activate ] && source .venv/bin/activate
exec python3 local_server.py --model stable-diffusion-v1-5/stable-diffusion-v1-5 "$@"
