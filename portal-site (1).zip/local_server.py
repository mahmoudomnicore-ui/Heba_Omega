#!/usr/bin/env python3
"""
Local image server for Play & Create Portal.

Runs an open-source text-to-image model on YOUR computer and also serves the website,
so the page and the model share one address (http://localhost:8000). No credits, no
subscriptions, no external image service.

Examples:
  python local_server.py --mock                                   # test the page, no model needed
  python local_server.py --model black-forest-labs/FLUX.1-schnell
  python local_server.py --model stable-diffusion-v1-5/stable-diffusion-v1-5

Arabic prompts are translated to English locally first (open image models understand
English best). Turn this off with --no-translate.

Endpoints:
  GET /health                                   -> JSON status
  GET /generate?prompt=...&width=..&height=..&seed=..  -> PNG image
  GET /, /index.html, /privacy.html, ...        -> the website files in this folder
"""
import argparse
import hashlib
import io
import json
import os
import random
import re
import struct
import sys
import threading
import time
import traceback
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

SITE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC = {
    "/": "index.html", "/index.html": "index.html", "/privacy.html": "privacy.html",
    "/terms.html": "terms.html", "/about.html": "about.html", "/ads.txt": "ads.txt", "/robots.txt": "robots.txt",
}
CTYPES = {".html": "text/html; charset=utf-8", ".txt": "text/plain; charset=utf-8"}

MAX_PROMPT_CHARS = 400
MAX_WAITING = 8  # the page can queue up to 8 storyboard frames at once
NEGATIVE = "low quality, blurry, distorted, watermark, text, signature"

# Protected characters/brands (keep in sync with index.html). Extend for your market.
PROTECTED = [
    "disney", "mickey", "minnie", "marvel", "avengers", "spider-man", "spiderman", "batman", "superman",
    "pokemon", "pikachu", "nintendo", "mario", "zelda", "star wars", "harry potter", "hello kitty",
    "frozen", "elsa", "simpsons", "coca-cola", "coca cola", "nike", "adidas", "mcdonald",
    "ديزني", "ميكي", "سبايدرمان", "باتمان", "سوبرمان", "بوكيمون", "ماريو",
]
# Family-site guard. FLUX has no built-in safety filter, so we refuse obvious explicit/gory prompts.
EXPLICIT_EN = re.compile(r"\b(nude|naked|nsfw|porn\w*|sex\w*|erotic|gore|bloody|beheading)\b", re.I)
EXPLICIT_AR = {"عاري", "عارية", "اباحي", "إباحي", "اباحية", "إباحية", "دموي", "دموية"}


def check_prompt(prompt):
    """Return an error message if the prompt must be refused, else None."""
    low = prompt.lower()
    if any(w in low for w in PROTECTED):
        return "This prompt names a protected character or brand. Describe your idea in your own words."
    if EXPLICIT_EN.search(prompt) or any(t in EXPLICIT_AR for t in re.findall(r"\w+", prompt)):
        return "This site is family-friendly. Please use a different description."
    return None


ARABIC_RE = re.compile(r"[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]")
MAX_CACHE_FILES = 200


def translate_segments(prompt, fn):
    """Translate only the comma-separated parts that contain Arabic letters; keep the rest as typed."""
    if fn is None or not ARABIC_RE.search(prompt):
        return prompt
    out = []
    for part in (p.strip() for p in re.split(r"[,،\n]+", prompt)):
        if not part:
            continue
        if ARABIC_RE.search(part):
            try:
                part = fn(part) or part
            except Exception as e:  # keep the original text if translation fails
                sys.stderr.write("translation failed: %r\n" % (e,))
        out.append(part)
    return ", ".join(out)


def make_translator():
    """Small local Arabic->English model (Helsinki-NLP/opus-mt-ar-en). None if unavailable."""
    try:
        import torch
        from transformers import MarianMTModel, MarianTokenizer

        name = "Helsinki-NLP/opus-mt-ar-en"
        tok = MarianTokenizer.from_pretrained(name)
        model = MarianMTModel.from_pretrained(name).eval()

        def tr(s):
            batch = tok([s], return_tensors="pt", truncation=True, max_length=128)
            with torch.no_grad():
                out = model.generate(**batch, max_new_tokens=100)
            return tok.decode(out[0], skip_special_tokens=True)

        print("Arabic -> English prompt translation is on.", file=sys.stderr)
        return tr
    except Exception as e:
        print("Arabic translation is unavailable (prompts will be used as typed): %r" % (e,), file=sys.stderr)
        return None


def prune_cache(d):
    """Keep only the newest MAX_CACHE_FILES images so the cache cannot fill the disk."""
    try:
        files = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".png")]
        if len(files) > MAX_CACHE_FILES:
            files.sort(key=os.path.getmtime)
            for f in files[: len(files) - MAX_CACHE_FILES]:
                os.remove(f)
    except OSError:
        pass


# ---------------------------------------------------------------- image engines
def png_bytes(w, h, rows):
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


class MockEngine:
    """No model: draws a seeded gradient so you can test the whole page quickly."""
    name = "mock"
    device = "none"
    mock = True

    def size_for(self, w, h):
        s = min(1.0, 480 / max(w, h))
        return max(64, int(w * s)), max(64, int(h * s))

    def settings_key(self):
        return "mock"

    def generate(self, prompt, w, h, seed):
        w, h = self.size_for(w, h)
        r = random.Random(hashlib.sha256(f"{prompt}|{seed}".encode()).digest())
        c1 = [r.randrange(40, 230) for _ in range(3)]
        c2 = [r.randrange(40, 230) for _ in range(3)]
        rows = []
        for y in range(h):
            ty = y / h
            row = bytearray()
            for x in range(w):
                t = (x / w + ty) / 2
                row += bytes(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
            rows.append(bytes(row))
        return png_bytes(w, h, rows)


class DiffusersEngine:
    mock = False

    def __init__(self, model_id, offload=None, steps=None):
        import torch
        from diffusers import AutoPipelineForText2Image

        self.name = model_id
        low = model_id.lower()
        if "flux" in low:
            self.kind, self.area, self.mult, self.steps, self.guidance = "flux", 1024 * 1024, 16, 4, 0.0
        elif "xl" in low:
            self.kind, self.area, self.mult, self.steps, self.guidance = "sdxl", 1024 * 1024, 8, 30, 7.0
        else:
            self.kind, self.area, self.mult, self.steps, self.guidance = "sd", 512 * 512, 8, 25, 7.5
        if steps:
            self.steps = steps

        if torch.cuda.is_available():
            self.device = "cuda"
        elif getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            self.device = "mps"
        else:
            self.device = "cpu"
        if self.kind == "flux":
            dtype = torch.bfloat16
        else:
            dtype = torch.float16 if self.device in ("cuda", "mps") else torch.float32

        print(f"Loading {model_id} on {self.device} ({dtype}). The first run downloads the model; this can take a long time.",
              file=sys.stderr)
        kwargs = {"torch_dtype": dtype, "use_safetensors": True}
        if self.kind == "sdxl" and dtype == torch.float16:
            kwargs["variant"] = "fp16"
        try:
            self.pipe = AutoPipelineForText2Image.from_pretrained(model_id, **kwargs)
        except Exception as e:  # most common: gated model without login
            msg = str(e)
            if any(k in msg for k in ("401", "403", "gated", "Access to model", "restricted")):
                print("\nThis model is gated. Open its Hugging Face page, accept the conditions, then run\n"
                      "  huggingface-cli login      (or:  hf auth login)\nand start the server again.\n", file=sys.stderr)
            raise
        # FLUX does not fit in most GPUs' memory, so offloading is automatic for it (use --no-offload to disable).
        if self.device == "cuda" and (offload or (offload is None and self.kind == "flux")):
            self.pipe.enable_model_cpu_offload()
        else:
            self.pipe.to(self.device)
        if self.kind == "sd" and self.device in ("mps", "cpu"):
            self.pipe.enable_attention_slicing()
        self._torch = torch

    def size_for(self, w, h):
        w, h = max(64, min(w, 4096)), max(64, min(h, 4096))
        s = min(1.0, (self.area / (w * h)) ** 0.5)
        nw = max(256, int(w * s) // self.mult * self.mult)
        nh = max(256, int(h * s) // self.mult * self.mult)
        return nw, nh

    def settings_key(self):
        return f"{self.name}|{self.steps}|{self.guidance}"

    def generate(self, prompt, w, h, seed):
        w, h = self.size_for(w, h)
        g = self._torch.Generator("cpu").manual_seed(seed)
        args = dict(prompt=prompt, height=h, width=w, num_inference_steps=self.steps, generator=g)
        if self.kind == "flux":
            out = self.pipe(guidance_scale=0.0, max_sequence_length=256, **args)
        else:
            out = self.pipe(negative_prompt=NEGATIVE, guidance_scale=self.guidance, **args)
        buf = io.BytesIO()
        out.images[0].save(buf, format="PNG")
        return buf.getvalue()


# ---------------------------------------------------------------- HTTP server
class PortalServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, addr, handler, engine, loopback, allow_origin, cache_dir):
        super().__init__(addr, handler)
        self.engine, self.loopback, self.allow_origin, self.cache_dir = engine, loopback, allow_origin, cache_dir
        self.gen_lock = threading.Lock()
        self.count_lock = threading.Lock()
        self.waiting = 0
        self.translate = None  # set in main()


class Handler(BaseHTTPRequestHandler):
    server_version = "PortalLocal/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _host_ok(self):
        if not self.server.loopback:
            return True
        host = urlsplit("//" + (self.headers.get("Host") or "")).hostname or ""
        return host in ("localhost", "127.0.0.1", "::1")

    def _send(self, code, body, ctype, cache="no-store"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        origin = self.headers.get("Origin")
        if origin and self.server.allow_origin and origin == self.server.allow_origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        try:
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass  # the browser stopped waiting; nothing to do

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self):
        if not self._host_ok():
            return self._json(403, {"error": "Forbidden host"})
        u = urlsplit(self.path)
        if u.path == "/health":
            e = self.server.engine
            return self._json(200, {"ok": True, "local_model": True, "model": e.name, "device": e.device,
                                    "mock": e.mock, "translate": self.server.translate is not None})
        if u.path == "/generate":
            return self._generate(u)
        name = STATIC.get(u.path)
        if name:
            fp = os.path.join(SITE_DIR, name)
            if os.path.isfile(fp):
                with open(fp, "rb") as f:
                    return self._send(200, f.read(), CTYPES.get(os.path.splitext(name)[1], "application/octet-stream"))
        return self._json(404, {"error": "Not found"})

    def _generate(self, u):
        q = parse_qs(u.query)
        prompt = (q.get("prompt", [""])[0]).strip()
        try:
            w = int(q.get("width", ["1024"])[0])
            h = int(q.get("height", ["1024"])[0])
            seed = int(q.get("seed", ["0"])[0] or 0)
        except ValueError:
            return self._json(400, {"error": "width, height and seed must be numbers"})
        if not prompt:
            return self._json(400, {"error": "Missing prompt"})
        if len(prompt) > MAX_PROMPT_CHARS:
            return self._json(400, {"error": f"Prompt is too long (max {MAX_PROMPT_CHARS} characters)"})
        text = translate_segments(prompt, self.server.translate)
        why = check_prompt(prompt) or (check_prompt(text) if text != prompt else None)
        if why:
            return self._json(400, {"error": why})
        if text != prompt:
            sys.stderr.write("translated: %s\n" % text[:200])
        if seed <= 0:
            seed = random.randrange(1, 2**31)

        eng = self.server.engine
        cache_path = None
        if self.server.cache_dir:
            key = hashlib.sha256(f"{eng.settings_key()}|{prompt}|{w}|{h}|{seed}".encode()).hexdigest()
            cache_path = os.path.join(self.server.cache_dir, key + ".png")
            if os.path.isfile(cache_path):
                with open(cache_path, "rb") as f:
                    return self._send(200, f.read(), "image/png", "private, max-age=86400")

        srv = self.server
        with srv.count_lock:
            if srv.waiting >= MAX_WAITING:
                return self._json(503, {"error": "The server is busy. Try again in a moment."})
            srv.waiting += 1
        try:
            with srv.gen_lock:
                t0 = time.time()
                png = eng.generate(text, w, h, seed)
                sys.stderr.write("generated in %.1fs\n" % (time.time() - t0))
        except Exception:
            traceback.print_exc()
            return self._json(500, {"error": "Generation failed on the server. Check the server window for details."})
        finally:
            with srv.count_lock:
                srv.waiting -= 1
        if cache_path:
            try:
                os.makedirs(srv.cache_dir, exist_ok=True)
                with open(cache_path, "wb") as f:
                    f.write(png)
                prune_cache(srv.cache_dir)
            except OSError:
                pass
        return self._send(200, png, "image/png", "private, max-age=86400")


def main():
    ap = argparse.ArgumentParser(description="Local image server for Play & Create Portal")
    ap.add_argument("--model", help="Hugging Face model id, e.g. black-forest-labs/FLUX.1-schnell")
    ap.add_argument("--mock", action="store_true", help="No model: draw gradients to test the page")
    ap.add_argument("--host", default="127.0.0.1", help="Default 127.0.0.1 (this computer only)")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--offload", dest="offload", action="store_const", const=True, default=None,
                    help="CUDA only: save GPU memory (slower). FLUX turns this on automatically")
    ap.add_argument("--no-offload", dest="offload", action="store_const", const=False,
                    help="CUDA only: keep the whole model on the GPU (FLUX then needs a lot of VRAM)")
    ap.add_argument("--no-translate", action="store_true", help="Do not translate Arabic prompts to English")
    ap.add_argument("--mock-translate", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--steps", type=int, help="Override the number of inference steps")
    ap.add_argument("--cache-dir", default=os.path.join(SITE_DIR, "cache"))
    ap.add_argument("--no-cache", action="store_true")
    ap.add_argument("--allow-origin", default="", help="Only if the page is hosted elsewhere, e.g. https://example.com")
    a = ap.parse_args()
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # Arabic text in a Windows console
    except Exception:
        pass

    if not a.mock and not a.model:
        ap.error("choose a model, for example:\n"
                 "  --model black-forest-labs/FLUX.1-schnell                (Apache-2.0, strong GPU, needs free Hugging Face login)\n"
                 "  --model stable-diffusion-v1-5/stable-diffusion-v1-5     (lighter; read its license first)\n"
                 "or use --mock to test the page without a model")
    engine = MockEngine() if a.mock else DiffusersEngine(a.model, offload=a.offload, steps=a.steps)
    loopback = a.host in ("127.0.0.1", "localhost", "::1")
    if not loopback:
        print("WARNING: anyone on your network can use this server and your computer's GPU.", file=sys.stderr)
    srv = PortalServer((a.host, a.port), Handler, engine, loopback, a.allow_origin, None if a.no_cache else a.cache_dir)
    if a.mock:
        srv.translate = (lambda s: "[en] " + s) if a.mock_translate else None
    elif not a.no_translate:
        srv.translate = make_translator()
    print(f"Ready. Open http://localhost:{a.port}  (model: {engine.name}, device: {engine.device})", file=sys.stderr)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.", file=sys.stderr)


if __name__ == "__main__":
    main()
