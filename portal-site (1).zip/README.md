# Play & Create Portal: launch checklist

## Files
- `index.html`: the whole app (22 tools, English/Arabic, ad slots)
- `privacy.html`, `terms.html`, `about.html`: TEMPLATES. Fill every [PLACEHOLDER], add real original text to About, and have a lawyer review them.
- `ads.txt`: replace `pub-XXXXXXXXXXXXXXXX` with your AdSense publisher ID. Serve it at `https://yourdomain/ads.txt`.
- `robots.txt`, `LICENSE.txt`

## Set up AdSense
1. Host the files on your own domain (Netlify, GitHub Pages or Cloudflare Pages all work). AdSense will not approve a claude.ai or free-subdomain preview.
2. Apply for AdSense and wait for approval.
3. In `index.html` fill `CONFIG.ADSENSE_CLIENT` (ca-pub-...) and the `AD_SLOTS` IDs from your AdSense account.
4. Keep the consent banner. Never ask users to click ads or trigger ads by actions; AdSense can ban the account.
5. If children are your main audience, enable child-directed treatment in AdSense.

## Reduce policy and copyright risk
- Add real original content (about text, short guides for each tool). Pages made only of auto-generated results risk rejection as low value.
- Extend the `BLOCK` list in `index.html` with protected names common in your market.
- Check the terms of the free image service in `CONFIG.IMAGE_URL` for commercial use, or swap in a service whose license you have read.
- Emoji and fonts used are the visitor's system fonts. Do not add third-party images, music or fonts without checking their licenses.

## Ownership (honest notes)
- Copyright in your original code and writing generally exists from creation, but rules differ by country, and AI-assisted work may have limited protection. Ask a local IP lawyer about registration.
- `FINGERPRINTS.txt` (SHA-256 hashes) shows the files have not changed since this package was made. It is an integrity record, not legal proof of ownership. Keep a dated copy (for example a private Git repository or a dated email to yourself).

## Before launch
Test every tool on a real phone and desktop (camera, microphone, video recording need a recent Chrome, Edge, Firefox or Safari and HTTPS).

## Local image model
See `README_LOCAL.md` (Arabic) to run an open-source image model on your own computer with `local_server.py`.
