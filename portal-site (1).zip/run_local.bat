@echo off
rem Starts the website AND your local image model. Then open http://localhost:8000
rem Use another model by adding it after the command, e.g.:
rem   run_local.bat --model black-forest-labs/FLUX.1-schnell
cd /d "%~dp0"
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python local_server.py --model stable-diffusion-v1-5/stable-diffusion-v1-5 %*
pause
